# blood_bank_app/models.py
from django.db import models

class Donor(models.Model):
    name = models.CharField(max_length=100)
    blood_type = models.CharField(max_length=10)
    contact = models.CharField(max_length=15, default='Not Provided')  # Add default value

    def __str__(self):
        return self.name
